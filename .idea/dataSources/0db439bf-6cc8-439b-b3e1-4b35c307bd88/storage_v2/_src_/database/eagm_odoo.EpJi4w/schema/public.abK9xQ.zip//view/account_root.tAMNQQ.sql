create view account_root(id, name, parent_id, company_id) as
SELECT DISTINCT ascii(account_account.code::text) * 1000 + ascii("substring"(account_account.code::text, 2, 1)) AS id,
                "left"(account_account.code::text, 2)                                                           AS name,
                ascii(account_account.code::text)                                                               AS parent_id,
                account_account.company_id
FROM account_account
WHERE account_account.code IS NOT NULL
UNION ALL
SELECT DISTINCT ascii(account_account.code::text)     AS id,
                "left"(account_account.code::text, 1) AS name,
                NULL::integer                         AS parent_id,
                account_account.company_id
FROM account_account
WHERE account_account.code IS NOT NULL;

alter table account_root
    owner to odoo14;

