create view report_project_task_user
            (nbr, id, date_assign, date_end, date_last_stage_update, date_deadline, user_id, project_id, priority, name,
             company_id, partner_id, stage_id, state, working_days_close, working_days_open, delay_endings_days,
             planned_date_begin, planned_date_end, progress, hours_effective, remaining_hours, hours_planned)
as
SELECT NULL::integer                     AS nbr,
       NULL::integer                     AS id,
       NULL::timestamp without time zone AS date_assign,
       NULL::timestamp without time zone AS date_end,
       NULL::timestamp without time zone AS date_last_stage_update,
       NULL::date                        AS date_deadline,
       NULL::integer                     AS user_id,
       NULL::integer                     AS project_id,
       NULL::character varying           AS priority,
       NULL::character varying           AS name,
       NULL::integer                     AS company_id,
       NULL::integer                     AS partner_id,
       NULL::integer                     AS stage_id,
       NULL::character varying           AS state,
       NULL::double precision            AS working_days_close,
       NULL::double precision            AS working_days_open,
       NULL::double precision            AS delay_endings_days,
       NULL::timestamp without time zone AS planned_date_begin,
       NULL::timestamp without time zone AS planned_date_end,
       NULL::double precision            AS progress,
       NULL::double precision            AS hours_effective,
       NULL::double precision            AS remaining_hours,
       NULL::double precision            AS hours_planned;

alter table report_project_task_user
    owner to odoo14;

