create view im_livechat_report_operator
            (id, partner_id, livechat_channel_id, nbr_channel, channel_id, start_date, duration, time_to_answer) as
SELECT NULL::bigint                      AS id,
       NULL::integer                     AS partner_id,
       NULL::integer                     AS livechat_channel_id,
       NULL::bigint                      AS nbr_channel,
       NULL::integer                     AS channel_id,
       NULL::timestamp without time zone AS start_date,
       NULL::double precision            AS duration,
       NULL::double precision            AS time_to_answer;

alter table im_livechat_report_operator
    owner to odoo14;

