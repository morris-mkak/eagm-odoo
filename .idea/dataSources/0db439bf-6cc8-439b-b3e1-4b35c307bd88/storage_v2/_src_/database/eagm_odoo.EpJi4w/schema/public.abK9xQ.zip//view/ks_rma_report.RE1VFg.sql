create view ks_rma_report
            (id, ks_product_id, ks_rma_id, product_uom, ks_picking_id, ks_currency_id, ks_date_closed, ks_warehouse_id,
             ks_date_cancelled, ks_returned_qty, ks_refund_qty, ks_refund_amount, nbr, ks_sequence_code,
             ks_date_requested, state, ks_refund_invoice_id, ks_confirmed_user_id, ks_selection, ks_sale_order_id,
             ks_purchase_order_id, ks_date_confirmed, ks_is_refund, ks_is_return, ks_return_picking_id, ks_partner_id,
             ks_user_id, ks_company_id, delay, ks_team_id, product_tmpl_id, commercial_partner_id, order_id)
as
SELECT NULL::integer           AS id,
       NULL::integer           AS ks_product_id,
       NULL::integer           AS ks_rma_id,
       NULL::integer           AS product_uom,
       NULL::integer           AS ks_picking_id,
       NULL::integer           AS ks_currency_id,
       NULL::date              AS ks_date_closed,
       NULL::integer           AS ks_warehouse_id,
       NULL::date              AS ks_date_cancelled,
       NULL::bigint            AS ks_returned_qty,
       NULL::bigint            AS ks_refund_qty,
       NULL::double precision  AS ks_refund_amount,
       NULL::bigint            AS nbr,
       NULL::character varying AS ks_sequence_code,
       NULL::date              AS ks_date_requested,
       NULL::character varying AS state,
       NULL::integer           AS ks_refund_invoice_id,
       NULL::integer           AS ks_confirmed_user_id,
       NULL::character varying AS ks_selection,
       NULL::integer           AS ks_sale_order_id,
       NULL::integer           AS ks_purchase_order_id,
       NULL::date              AS ks_date_confirmed,
       NULL::boolean           AS ks_is_refund,
       NULL::boolean           AS ks_is_return,
       NULL::integer           AS ks_return_picking_id,
       NULL::integer           AS ks_partner_id,
       NULL::integer           AS ks_user_id,
       NULL::integer           AS ks_company_id,
       NULL::double precision  AS delay,
       NULL::integer           AS ks_team_id,
       NULL::integer           AS product_tmpl_id,
       NULL::integer           AS commercial_partner_id,
       NULL::integer           AS order_id;

alter table ks_rma_report
    owner to odoo14;

