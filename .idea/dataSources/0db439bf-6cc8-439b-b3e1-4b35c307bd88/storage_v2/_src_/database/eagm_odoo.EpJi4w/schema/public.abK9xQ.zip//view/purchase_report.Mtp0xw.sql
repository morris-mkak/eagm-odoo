create view purchase_report
            (order_id, id, date_order, state, date_approve, dest_address_id, partner_id, user_id, company_id,
             fiscal_position_id, product_id, product_tmpl_id, category_id, currency_id, product_uom, delay, delay_pass,
             nbr_lines, price_total, price_average, country_id, commercial_partner_id, account_analytic_id, weight,
             volume, untaxed_total, qty_ordered, qty_received, qty_billed, qty_to_be_billed, picking_type_id,
             effective_date, discount)
as
WITH currency_rate AS (SELECT r.currency_id,
                              COALESCE(r.company_id, c.id) AS company_id,
                              r.rate,
                              r.name                       AS date_start,
                              (SELECT r2.name
                               FROM res_currency_rate r2
                               WHERE r2.name > r.name
                                 AND r2.currency_id = r.currency_id
                                 AND (r2.company_id IS NULL OR r2.company_id = c.id)
                               ORDER BY r2.name
                               LIMIT 1)                    AS date_end
                       FROM res_currency_rate r
                                JOIN res_company c ON r.company_id IS NULL OR r.company_id = c.id)
SELECT po.id                                                                                                       AS order_id,
       min(l.id)                                                                                                   AS id,
       po.date_order,
       po.state,
       po.date_approve,
       po.dest_address_id,
       po.partner_id,
       po.user_id,
       po.company_id,
       po.fiscal_position_id,
       l.product_id,
       p.product_tmpl_id,
       t.categ_id                                                                                                  AS category_id,
       po.currency_id,
       t.uom_id                                                                                                    AS product_uom,
       date_part('epoch'::text, age(po.date_approve, po.date_order)) /
       (24 * 60 * 60)::numeric(16, 2)::double precision                                                            AS delay,
       date_part('epoch'::text, age(l.date_planned, po.date_order)) /
       (24 * 60 * 60)::numeric(16, 2)::double precision                                                            AS delay_pass,
       count(*)                                                                                                    AS nbr_lines,
       sum(l.price_total::double precision /
           COALESCE(po.currency_rate, 1.0::double precision))::numeric(16, 2)                                      AS price_total,
       (sum((l.product_qty * (1.0 - COALESCE(l.discount, 0.0) / 100.0) * l.price_unit)::double precision /
            COALESCE(po.currency_rate, 1.0::double precision)) /
        NULLIF(sum(l.product_qty / line_uom.factor * product_uom.factor),
               0.0)::double precision)::numeric(16, 2)                                                             AS price_average,
       partner.country_id,
       partner.commercial_partner_id,
       analytic_account.id                                                                                         AS account_analytic_id,
       sum(p.weight * l.product_qty / line_uom.factor * product_uom.factor)                                        AS weight,
       sum(p.volume * l.product_qty / line_uom.factor * product_uom.factor)                                        AS volume,
       sum(l.price_subtotal::double precision /
           COALESCE(po.currency_rate, 1.0::double precision))::numeric(16, 2)                                      AS untaxed_total,
       sum(l.product_qty / line_uom.factor * product_uom.factor)                                                   AS qty_ordered,
       sum(l.qty_received / line_uom.factor * product_uom.factor)                                                  AS qty_received,
       sum(l.qty_invoiced / line_uom.factor * product_uom.factor)                                                  AS qty_billed,
       CASE
           WHEN t.purchase_method::text = 'purchase'::text THEN
               sum(l.product_qty / line_uom.factor * product_uom.factor) -
               sum(l.qty_invoiced / line_uom.factor * product_uom.factor)
           ELSE sum(l.qty_received / line_uom.factor * product_uom.factor) -
                sum(l.qty_invoiced / line_uom.factor * product_uom.factor)
           END                                                                                                     AS qty_to_be_billed,
       spt.warehouse_id                                                                                            AS picking_type_id,
       po.effective_date,
       l.discount
FROM purchase_order_line l
         JOIN purchase_order po ON l.order_id = po.id
         JOIN res_partner partner ON po.partner_id = partner.id
         LEFT JOIN product_product p ON l.product_id = p.id
         LEFT JOIN product_template t ON p.product_tmpl_id = t.id
         LEFT JOIN uom_uom line_uom ON line_uom.id = l.product_uom
         LEFT JOIN uom_uom product_uom ON product_uom.id = t.uom_id
         LEFT JOIN account_analytic_account analytic_account ON l.account_analytic_id = analytic_account.id
         LEFT JOIN currency_rate cr ON cr.currency_id = po.currency_id AND cr.company_id = po.company_id AND
                                       cr.date_start <= COALESCE(po.date_order::timestamp with time zone, now()) AND
                                       (cr.date_end IS NULL OR
                                        cr.date_end > COALESCE(po.date_order::timestamp with time zone, now()))
         LEFT JOIN stock_picking_type spt ON spt.id = po.picking_type_id
GROUP BY po.company_id, po.user_id, po.partner_id, line_uom.factor, po.currency_id, l.price_unit, po.date_approve,
         l.date_planned, l.product_uom, po.dest_address_id, po.fiscal_position_id, l.product_id, p.product_tmpl_id,
         t.categ_id, po.date_order, po.state, line_uom.uom_type, line_uom.category_id, t.uom_id, t.purchase_method,
         line_uom.id, product_uom.factor, partner.country_id, partner.commercial_partner_id, analytic_account.id, po.id,
         spt.warehouse_id, po.effective_date, l.discount;

alter table purchase_report
    owner to odoo14;

