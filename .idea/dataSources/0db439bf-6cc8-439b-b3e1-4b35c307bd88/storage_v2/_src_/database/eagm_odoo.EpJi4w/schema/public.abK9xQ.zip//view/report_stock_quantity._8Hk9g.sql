create view report_stock_quantity(id, product_id, state, date, product_qty, company_id, warehouse_id) as
WITH existing_sm(id, product_id, product_qty, date, state, company_id, whs_id, whd_id, ls_usage, ld_usage)
         AS (SELECT m.id,
                    m.product_id,
                    m.product_qty,
                    m.date,
                    m.state,
                    m.company_id,
                    whs.id,
                    whd.id,
                    ls.usage,
                    ld.usage
             FROM stock_move m
                      LEFT JOIN stock_location ls ON ls.id = m.location_id
                      LEFT JOIN stock_location ld ON ld.id = m.location_dest_id
                      LEFT JOIN stock_warehouse whs ON ls.parent_path::text ~~ concat('%/', whs.view_location_id, '/%')
                      LEFT JOIN stock_warehouse whd ON ld.parent_path::text ~~ concat('%/', whd.view_location_id, '/%')
                      LEFT JOIN product_product pp ON pp.id = m.product_id
                      LEFT JOIN product_template pt ON pt.id = pp.product_tmpl_id
             WHERE pt.type::text = 'product'::text
               AND (whs.id IS NOT NULL OR whd.id IS NOT NULL)
               AND (whs.id IS NULL OR whd.id IS NULL OR whs.id <> whd.id)
               AND m.product_qty <> 0::numeric
               AND (m.state::text <> ALL (ARRAY ['draft'::character varying::text, 'cancel'::character varying::text]))
               AND (m.state::text <> 'done'::text OR
                    m.date >= (timezone('utc'::text, now())::date - '3 mons'::interval))),
     all_sm(id, product_id, product_qty, date, state, company_id, whs_id, whd_id, ls_usage, ld_usage) AS (SELECT sm.id,
                                                                                                                 sm.product_id,
                                                                                                                 CASE
                                                                                                                     WHEN is_duplicated.is_duplicated = 0
                                                                                                                         THEN sm.product_qty
                                                                                                                     WHEN
                                                                                                                         sm.whs_id IS NOT NULL AND
                                                                                                                         sm.whd_id IS NOT NULL AND
                                                                                                                         sm.whs_id <>
                                                                                                                         sm.whd_id
                                                                                                                         THEN sm.product_qty
                                                                                                                     ELSE 0::numeric
                                                                                                                     END AS "case",
                                                                                                                 sm.date,
                                                                                                                 sm.state,
                                                                                                                 sm.company_id,
                                                                                                                 CASE
                                                                                                                     WHEN is_duplicated.is_duplicated = 0
                                                                                                                         THEN sm.whs_id
                                                                                                                     ELSE NULL::integer
                                                                                                                     END AS "case",
                                                                                                                 CASE
                                                                                                                     WHEN
                                                                                                                         is_duplicated.is_duplicated =
                                                                                                                         0 AND
                                                                                                                         NOT (
                                                                                                                             sm.whs_id IS NOT NULL AND
                                                                                                                             sm.whd_id IS NOT NULL AND
                                                                                                                             sm.whs_id <>
                                                                                                                             sm.whd_id)
                                                                                                                         THEN sm.whd_id
                                                                                                                     WHEN
                                                                                                                         is_duplicated.is_duplicated =
                                                                                                                         1 AND
                                                                                                                         sm.whs_id IS NOT NULL AND
                                                                                                                         sm.whd_id IS NOT NULL AND
                                                                                                                         sm.whs_id <>
                                                                                                                         sm.whd_id
                                                                                                                         THEN sm.whd_id
                                                                                                                     ELSE NULL::integer
                                                                                                                     END AS "case",
                                                                                                                 CASE
                                                                                                                     WHEN is_duplicated.is_duplicated = 0
                                                                                                                         THEN sm.ls_usage
                                                                                                                     ELSE NULL::character varying
                                                                                                                     END AS "case",
                                                                                                                 CASE
                                                                                                                     WHEN
                                                                                                                         is_duplicated.is_duplicated =
                                                                                                                         0 AND
                                                                                                                         NOT (
                                                                                                                             sm.whs_id IS NOT NULL AND
                                                                                                                             sm.whd_id IS NOT NULL AND
                                                                                                                             sm.whs_id <>
                                                                                                                             sm.whd_id)
                                                                                                                         THEN sm.ld_usage
                                                                                                                     WHEN
                                                                                                                         is_duplicated.is_duplicated =
                                                                                                                         1 AND
                                                                                                                         sm.whs_id IS NOT NULL AND
                                                                                                                         sm.whd_id IS NOT NULL AND
                                                                                                                         sm.whs_id <>
                                                                                                                         sm.whd_id
                                                                                                                         THEN sm.ld_usage
                                                                                                                     ELSE NULL::character varying
                                                                                                                     END AS "case"
                                                                                                          FROM generate_series(0, 1, 1) is_duplicated(is_duplicated),
                                                                                                               existing_sm sm)
SELECT min(forecast_qty.id)          AS id,
       forecast_qty.product_id,
       forecast_qty.state,
       forecast_qty.date,
       sum(forecast_qty.product_qty) AS product_qty,
       forecast_qty.company_id,
       forecast_qty.warehouse_id
FROM (SELECT m.id,
             m.product_id,
             CASE
                 WHEN m.whs_id IS NOT NULL AND m.whd_id IS NULL THEN 'out'::text
                 WHEN m.whd_id IS NOT NULL AND m.whs_id IS NULL THEN 'in'::text
                 ELSE NULL::text
                 END      AS state,
             m.date::date AS date,
             CASE
                 WHEN m.whs_id IS NOT NULL AND m.whd_id IS NULL THEN - m.product_qty
                 WHEN m.whd_id IS NOT NULL AND m.whs_id IS NULL THEN m.product_qty
                 ELSE NULL::numeric
                 END      AS product_qty,
             m.company_id,
             CASE
                 WHEN m.whs_id IS NOT NULL AND m.whd_id IS NULL THEN m.whs_id
                 WHEN m.whd_id IS NOT NULL AND m.whs_id IS NULL THEN m.whd_id
                 ELSE NULL::integer
                 END      AS warehouse_id
      FROM all_sm m
      WHERE m.product_qty <> 0::numeric
        AND m.state::text <> 'done'::text
      UNION ALL
      SELECT - q.id           AS id,
             q.product_id,
             'forecast'::text AS state,
             date.date::date  AS date,
             q.quantity       AS product_qty,
             q.company_id,
             wh.id            AS warehouse_id
      FROM generate_series(timezone('utc'::text, now())::date - '3 mons'::interval,
                           timezone('utc'::text, now())::date + '3 mons'::interval, '1 day'::interval) date(date),
           stock_quant q
               LEFT JOIN stock_location l ON l.id = q.location_id
               LEFT JOIN stock_warehouse wh ON l.parent_path::text ~~ concat('%/', wh.view_location_id, '/%')
      WHERE l.usage::text = 'internal'::text AND wh.id IS NOT NULL
         OR l.usage::text = 'transit'::text
      UNION ALL
      SELECT m.id,
             m.product_id,
             'forecast'::text                          AS state,
             generate_series(
                     CASE
                         WHEN m.state::text = 'done'::text THEN timezone('utc'::text, now())::date - '3 mons'::interval
                         ELSE m.date::date::timestamp without time zone
                         END,
                     CASE
                         WHEN m.state::text <> 'done'::text THEN timezone('utc'::text, now())::date + '3 mons'::interval
                         ELSE m.date::date - '1 day'::interval
                         END, '1 day'::interval)::date AS date,
             CASE
                 WHEN m.whs_id IS NOT NULL AND m.whd_id IS NULL AND m.state::text = 'done'::text THEN m.product_qty
                 WHEN m.whd_id IS NOT NULL AND m.whs_id IS NULL AND m.state::text = 'done'::text THEN - m.product_qty
                 WHEN m.whs_id IS NOT NULL AND m.whd_id IS NULL THEN - m.product_qty
                 WHEN m.whd_id IS NOT NULL AND m.whs_id IS NULL THEN m.product_qty
                 ELSE NULL::numeric
                 END                                   AS product_qty,
             m.company_id,
             CASE
                 WHEN m.whs_id IS NOT NULL AND m.whd_id IS NULL THEN m.whs_id
                 WHEN m.whd_id IS NOT NULL AND m.whs_id IS NULL THEN m.whd_id
                 ELSE NULL::integer
                 END                                   AS warehouse_id
      FROM all_sm m
      WHERE m.product_qty <> 0::numeric) forecast_qty
GROUP BY forecast_qty.product_id, forecast_qty.state, forecast_qty.date, forecast_qty.company_id,
         forecast_qty.warehouse_id;

alter table report_stock_quantity
    owner to odoo14;

