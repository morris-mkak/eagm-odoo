create view sale_report
            (id, product_id, product_uom, product_uom_qty, qty_delivered, qty_invoiced, qty_to_invoice, price_total,
             price_subtotal, untaxed_amount_to_invoice, untaxed_amount_invoiced, nbr, name, date, state, partner_id,
             user_id, company_id, campaign_id, medium_id, source_id, delay, categ_id, pricelist_id, analytic_account_id,
             team_id, product_tmpl_id, country_id, industry_id, commercial_partner_id, weight, volume, discount,
             discount_amount, order_id, woo_instance_id, margin, warehouse_id, invoice_status)
as
SELECT COALESCE(min(l.id), - s.id)                      AS id,
       l.product_id,
       t.uom_id                                         AS product_uom,
       CASE
           WHEN l.product_id IS NOT NULL THEN sum(l.product_uom_qty / u.factor * u2.factor)
           ELSE 0::numeric
           END                                          AS product_uom_qty,
       CASE
           WHEN l.product_id IS NOT NULL THEN sum(l.qty_delivered / u.factor * u2.factor)
           ELSE 0::numeric
           END                                          AS qty_delivered,
       CASE
           WHEN l.product_id IS NOT NULL THEN sum(l.qty_invoiced / u.factor * u2.factor)
           ELSE 0::numeric
           END                                          AS qty_invoiced,
       CASE
           WHEN l.product_id IS NOT NULL THEN sum(l.qty_to_invoice / u.factor * u2.factor)
           ELSE 0::numeric
           END                                          AS qty_to_invoice,
       CASE
           WHEN l.product_id IS NOT NULL THEN sum(l.price_total /
                                                  CASE COALESCE(s.currency_rate, 0::numeric)
                                                      WHEN 0 THEN 1.0
                                                      ELSE s.currency_rate
                                                      END)
           ELSE 0::numeric
           END                                          AS price_total,
       CASE
           WHEN l.product_id IS NOT NULL THEN sum(l.price_subtotal /
                                                  CASE COALESCE(s.currency_rate, 0::numeric)
                                                      WHEN 0 THEN 1.0
                                                      ELSE s.currency_rate
                                                      END)
           ELSE 0::numeric
           END                                          AS price_subtotal,
       CASE
           WHEN l.product_id IS NOT NULL THEN sum(l.untaxed_amount_to_invoice /
                                                  CASE COALESCE(s.currency_rate, 0::numeric)
                                                      WHEN 0 THEN 1.0
                                                      ELSE s.currency_rate
                                                      END)
           ELSE 0::numeric
           END                                          AS untaxed_amount_to_invoice,
       CASE
           WHEN l.product_id IS NOT NULL THEN sum(l.untaxed_amount_invoiced /
                                                  CASE COALESCE(s.currency_rate, 0::numeric)
                                                      WHEN 0 THEN 1.0
                                                      ELSE s.currency_rate
                                                      END)
           ELSE 0::numeric
           END                                          AS untaxed_amount_invoiced,
       count(*)                                         AS nbr,
       s.name,
       s.date_order                                     AS date,
       s.state,
       s.partner_id,
       s.user_id,
       s.company_id,
       s.campaign_id,
       s.medium_id,
       s.source_id,
       date_part('epoch'::text, avg(date_trunc('day'::text, s.date_order) - date_trunc('day'::text, s.create_date))) /
       (24 * 60 * 60)::numeric(16, 2)::double precision AS delay,
       t.categ_id,
       s.pricelist_id,
       s.analytic_account_id,
       s.team_id,
       p.product_tmpl_id,
       partner.country_id,
       partner.industry_id,
       partner.commercial_partner_id,
       CASE
           WHEN l.product_id IS NOT NULL THEN sum(p.weight * l.product_uom_qty / u.factor * u2.factor)
           ELSE 0::numeric
           END                                          AS weight,
       CASE
           WHEN l.product_id IS NOT NULL THEN sum(p.volume * l.product_uom_qty / u.factor * u2.factor)
           ELSE 0::numeric
           END                                          AS volume,
       l.discount,
       CASE
           WHEN l.product_id IS NOT NULL THEN sum(l.price_unit * l.product_uom_qty * l.discount / 100.0 /
                                                  CASE COALESCE(s.currency_rate, 0::numeric)
                                                      WHEN 0 THEN 1.0
                                                      ELSE s.currency_rate
                                                      END)
           ELSE 0::numeric
           END                                          AS discount_amount,
       s.id                                             AS order_id,
       s.woo_instance_id,
       sum(l.margin /
           CASE COALESCE(s.currency_rate, 0::numeric)
               WHEN 0 THEN 1.0
               ELSE s.currency_rate
               END)                                     AS margin,
       s.warehouse_id,
       s.invoice_status
FROM sale_order_line l
         RIGHT JOIN sale_order s ON s.id = l.order_id
         JOIN res_partner partner ON s.partner_id = partner.id
         LEFT JOIN product_product p ON l.product_id = p.id
         LEFT JOIN product_template t ON p.product_tmpl_id = t.id
         LEFT JOIN uom_uom u ON u.id = l.product_uom
         LEFT JOIN uom_uom u2 ON u2.id = t.uom_id
         LEFT JOIN product_pricelist pp ON s.pricelist_id = pp.id
WHERE l.display_type IS NULL
GROUP BY l.product_id, l.order_id, t.uom_id, t.categ_id, s.name, s.date_order, s.partner_id, s.user_id, s.state,
         s.company_id, s.campaign_id, s.medium_id, s.source_id, s.pricelist_id, s.analytic_account_id, s.team_id,
         p.product_tmpl_id, partner.country_id, partner.industry_id, partner.commercial_partner_id, l.discount, s.id,
         s.woo_instance_id, s.warehouse_id, s.invoice_status;

alter table sale_report
    owner to odoo14;

