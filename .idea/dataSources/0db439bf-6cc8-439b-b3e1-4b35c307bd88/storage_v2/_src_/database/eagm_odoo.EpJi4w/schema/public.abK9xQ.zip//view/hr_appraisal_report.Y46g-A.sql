create view hr_appraisal_report (id, create_date, employee_id, department_id, deadline, final_interview, state) as
SELECT min(a.id)              AS id,
       date(a.create_date)    AS create_date,
       a.employee_id,
       e.department_id,
       a.date_close           AS deadline,
       a.date_final_interview AS final_interview,
       a.state
FROM hr_appraisal a
         LEFT JOIN hr_employee e ON e.id = a.employee_id
GROUP BY a.id, a.create_date, a.state, a.employee_id, a.date_close, a.date_final_interview, e.department_id;

alter table hr_appraisal_report
    owner to odoo14;

