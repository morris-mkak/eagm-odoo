create view helpdesk_sla_report_analysis
            (id, create_date, ticket_id, team_id, ticket_stage_id, ticket_type_id, user_id, partner_id, company_id,
             priority, ticket_failed, ticket_deadline, ticket_close_hours, ticket_open_hours, ticket_assignation_hours,
             ticket_closed, sla_id, sla_stage_id, sla_deadline, sla_reached_datetime, sla_exceeded_days, sla_status,
             sla_status_failed)
as
SELECT st.id,
       t.create_date,
       t.id                                                                                                          AS ticket_id,
       t.team_id,
       t.stage_id                                                                                                    AS ticket_stage_id,
       t.ticket_type_id,
       t.user_id,
       t.partner_id,
       t.company_id,
       t.priority,
       t.sla_reached_late OR t.sla_deadline < timezone('UTC'::text, now())                                           AS ticket_failed,
       t.sla_deadline                                                                                                AS ticket_deadline,
       t.close_hours                                                                                                 AS ticket_close_hours,
       date_part('hour'::text, COALESCE(t.assign_date::timestamp with time zone, now()) -
                               t.create_date::timestamp with time zone)                                              AS ticket_open_hours,
       t.assign_hours                                                                                                AS ticket_assignation_hours,
       sta.is_close                                                                                                  AS ticket_closed,
       st.sla_id,
       sla.stage_id                                                                                                  AS sla_stage_id,
       st.deadline                                                                                                   AS sla_deadline,
       st.reached_datetime                                                                                           AS sla_reached_datetime,
       st.exceeded_days                                                                                              AS sla_exceeded_days,
       CASE
           WHEN st.reached_datetime IS NOT NULL AND st.reached_datetime < st.deadline THEN 'reached'::text
           WHEN st.reached_datetime IS NOT NULL AND st.reached_datetime >= st.deadline THEN 'failed'::text
           WHEN st.reached_datetime IS NULL AND st.deadline > now() THEN 'ongoing'::text
           ELSE 'failed'::text
           END                                                                                                       AS sla_status,
       st.reached_datetime >= st.deadline OR st.reached_datetime IS NULL AND st.deadline <
                                                                             timezone('UTC'::text, now())            AS sla_status_failed
FROM helpdesk_ticket t
         LEFT JOIN helpdesk_stage sta ON t.stage_id = sta.id
         LEFT JOIN helpdesk_sla_status st ON t.id = st.ticket_id
         LEFT JOIN helpdesk_sla sla ON st.sla_id = sla.id;

alter table helpdesk_sla_report_analysis
    owner to odoo14;

