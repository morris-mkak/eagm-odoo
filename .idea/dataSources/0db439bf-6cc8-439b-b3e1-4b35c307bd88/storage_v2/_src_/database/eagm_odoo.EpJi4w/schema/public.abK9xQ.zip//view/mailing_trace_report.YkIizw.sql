create view mailing_trace_report
            (id, name, mailing_type, campaign, scheduled_date, state, email_from, sent, delivered, opened, replied,
             clicked, bounced)
as
SELECT min(trace.id)                            AS id,
       utm_source.name,
       mailing.mailing_type,
       utm_campaign.name                        AS campaign,
       trace.scheduled                          AS scheduled_date,
       mailing.state,
       mailing.email_from,
       count(trace.sent)                        AS sent,
       count(trace.sent) - count(trace.bounced) AS delivered,
       count(trace.opened)                      AS opened,
       count(trace.replied)                     AS replied,
       count(trace.clicked)                     AS clicked,
       count(trace.bounced)                     AS bounced
FROM mailing_trace trace
         LEFT JOIN mailing_mailing mailing ON trace.mass_mailing_id = mailing.id
         LEFT JOIN utm_campaign utm_campaign ON mailing.campaign_id = utm_campaign.id
         LEFT JOIN utm_source utm_source ON mailing.source_id = utm_source.id
WHERE mailing.use_in_marketing_automation IS NOT TRUE
GROUP BY trace.scheduled, utm_source.name, utm_campaign.name, mailing.mailing_type, mailing.state, mailing.email_from;

alter table mailing_trace_report
    owner to odoo14;

