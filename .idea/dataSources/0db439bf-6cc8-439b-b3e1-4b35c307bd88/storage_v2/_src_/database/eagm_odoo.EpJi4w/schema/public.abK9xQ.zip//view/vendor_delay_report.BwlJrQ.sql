create view vendor_delay_report
            (id, date, purchase_line_id, product_id, category_id, partner_id, qty_total, qty_on_time) as
SELECT NULL::integer                     AS id,
       NULL::timestamp without time zone AS date,
       NULL::integer                     AS purchase_line_id,
       NULL::integer                     AS product_id,
       NULL::integer                     AS category_id,
       NULL::integer                     AS partner_id,
       NULL::double precision            AS qty_total,
       NULL::numeric                     AS qty_on_time;

alter table vendor_delay_report
    owner to odoo14;

