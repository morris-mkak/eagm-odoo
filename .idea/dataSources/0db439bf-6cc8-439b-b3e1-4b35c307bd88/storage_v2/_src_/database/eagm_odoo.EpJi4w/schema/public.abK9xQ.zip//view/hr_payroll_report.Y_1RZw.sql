create view hr_payroll_report
            (id, count, count_work, count_work_hours, count_leave, count_leave_unpaid, count_unforeseen_absence,
             leave_basic_wage, name, date_from, date_to, employee_id, department_id, job_id, company_id, work_code,
             work_type, number_of_days, number_of_hours, net_wage, basic_wage, gross_wage)
as
SELECT NULL::integer           AS id,
       NULL::integer           AS count,
       NULL::double precision  AS count_work,
       NULL::double precision  AS count_work_hours,
       NULL::double precision  AS count_leave,
       NULL::double precision  AS count_leave_unpaid,
       NULL::double precision  AS count_unforeseen_absence,
       NULL::numeric           AS leave_basic_wage,
       NULL::character varying AS name,
       NULL::date              AS date_from,
       NULL::date              AS date_to,
       NULL::integer           AS employee_id,
       NULL::integer           AS department_id,
       NULL::integer           AS job_id,
       NULL::integer           AS company_id,
       NULL::integer           AS work_code,
       NULL::text              AS work_type,
       NULL::double precision  AS number_of_days,
       NULL::double precision  AS number_of_hours,
       NULL::numeric           AS net_wage,
       NULL::numeric           AS basic_wage,
       NULL::numeric           AS gross_wage;

alter table hr_payroll_report
    owner to odoo14;

